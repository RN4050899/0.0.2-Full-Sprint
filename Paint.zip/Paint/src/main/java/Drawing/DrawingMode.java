package Drawing;

/**
 * creates a constant on what type of tool is selected*
 */
public enum DrawingMode {
    DRAW(),
    SELECT()
}

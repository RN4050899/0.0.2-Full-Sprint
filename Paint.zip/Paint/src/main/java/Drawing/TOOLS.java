package Drawing;

/**
 * * creates the type of tool used in the Tools
 */

public enum TOOLS {
    PENCIL(),
    LINE(),
    ERASER(),
    RECTANGLE(),
    SQUARE(),
    CIRCLE(),
    ELLIPSE(),
    TRIANGLE(),
    NGON(),
    EYEDROPPER(),
    SELECT(),
    NONE()
}

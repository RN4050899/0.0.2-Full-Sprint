package com.example.paint;

import Drawing.DrawingMode;
import Drawing.TOOLS;
import DrawingTools.*;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.ToolBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.Slider;

import WarningFolder.Warning;
import javafx.scene.transform.Rotate;
import javafx.stage.FileChooser;
import javafx.stage.Stage;


import javax.imageio.ImageIO;
import javax.swing.text.rtf.RTFEditorKit;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Stack;

public class PaintCanvas extends Canvas{
    private Canvas canvas;
    private GraphicsContext gc;
    private WritableImage selectedImage;
    private File openedFile;
    private File savedFile;
    private Image redrawnImage;
    private DrawingMode drawMode;
    private TOOLS drawTools;
    private Color strokeColor;
    private BaseShape currentShape;
    private ImageView currentSelection;
    private Selection selection;
    private int Sides = 5;
    private Slider strokeSize;
    private Rectangler rectangle;
    private boolean modified = false;
    private Stack<Image> undoHistory;
    private Stack<Image> redoHistory;
    private String autoSaveLocation;


    /**
     *
     * @param canvas creates all the tools needed to go on canvas
     */
    public PaintCanvas(Canvas canvas){
        undoHistory = new Stack<>();
        redoHistory = new Stack<>();
        this.canvas = canvas;
        canvas.setWidth(1000);
        canvas.setHeight(720);
        this.gc = canvas.getGraphicsContext2D();
        this.strokeColor = Color.BLACK;
        gc.setLineWidth(10);
        drawTools = TOOLS.NONE;
        canvasSetter();
        redrawnImage = canvas.snapshot(null, null);
        redrawCanvas();


    }

    /**
     * * sets up the canvas
     */
    private void canvasSetter(){
        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, e-> {
            if (drawTools == TOOLS.NONE) {
                return;
            }
            redrawnImage = canvas.snapshot(null, null);
            if (drawMode != DrawingMode.SELECT) {
                switch (drawTools) {
                    case PENCIL:
                        currentShape = new Pencil(e.getX(), e.getY());
                        break;
                    case LINE:
                        currentShape = new Line(e.getX(), e.getY());
                        break;
                    case ERASER:
                        currentShape = new Eraser(e.getX(), e.getY());
                        break;
                    case RECTANGLE:
                        currentShape = new Rectangler(e.getX(), e.getY());
                        break;
                    case SQUARE:
                        currentShape = new Square(e.getX(), e.getY());
                        break;
                    case CIRCLE:
                        currentShape = new Circle(e.getX(), e.getY());
                        break;
                    case ELLIPSE:
                        currentShape = new Ellipse(e.getX(), e.getY());
                        break;
                    case TRIANGLE:
                        currentShape = new Triangle(e.getX(), e.getY());
                        break;
                    case EYEDROPPER:
                        Color color = redrawnImage.getPixelReader().getColor((int)e.getX(), (int)e.getY());
                        Main.paintController.getColorPicker().setValue(color);
                        setStrokeColor(color);
                        break;
                    case NGON:
                        currentShape = new Ngon(e.getX(), e.getY());
                }

            }
            else {
                if (currentSelection == null) {
                    selection = new Selection(e.getX(), e.getY());
                    rectangle = new Rectangler(e.getX(), e.getY());
                }
            }
            modified = true;


        });

        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, e ->{
            if(drawTools == TOOLS.NONE || drawTools == TOOLS.EYEDROPPER){
                return;
            }
            redrawCanvas();

            if(drawMode != DrawingMode.SELECT){
                currentShape.setEnd(e.getX(), e.getY());
                if(!currentShape.getIsPolygon()){
                    currentShape.draw(gc);
                }
                else{
                    currentShape.draw(gc, Sides);
                }
            }else{
                if(currentSelection == null){
                    rectangle.setEnd(e.getX(), e.getY());
                    rectangle.drawSelection(gc);
                    selection.setEnd(e.getX(), e.getY());
                }
            }
            modified = true;

        });

        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, (MouseEvent e) ->{
            if(drawTools == TOOLS.NONE){
                return;
            }
            undoHistory.add(redrawnImage);
            redrawCanvas();

            if(drawMode!=DrawingMode.SELECT){
                currentShape.setEnd(e.getX(), e.getY());
                if(!currentShape.getIsPolygon()){
                    currentShape.draw(gc);
                }
                else{
                    currentShape.draw(gc,Sides);
                }
            }else{
                if(currentSelection == null){
                    rectangle.setEnd(e.getX(), e.getY());
                    rectangle.drawSelection(gc);
                    selection.setEnd(e.getX(), e.getY());
                    selection.setImage(gc);
                    currentSelection = selection.getCurrentSelection();
                }
                redrawnImage = this.getRegion(e.getX(), e.getY(), e.getX(), e.getY());

            }
            redrawnImage = canvas.snapshot(null,null);
            modified = true;
                });

    }
    public void redrawCanvas(){
        this.canvas.getGraphicsContext2D().drawImage(redrawnImage, 0, 0, redrawnImage.getWidth(), redrawnImage.getHeight());
    }

    public void loadImageFromFile(File imageFile){
        Image image = null;
        try{
            image = new Image(new FileInputStream(imageFile.getAbsolutePath()));
        }catch(FileNotFoundException e ){
            System.out.println("File not found");
        }
        openedFile = imageFile;
        loadingImage(image);
    }

    public void loadingImage(Image image){
        if(image.getWidth() > canvas.getWidth()){
            canvas.setWidth(image.getWidth());
        }
        if(image.getHeight() > canvas.getHeight()) {
            canvas.setHeight(image.getHeight());
        }
        gc.drawImage(image,0,0,image.getWidth(),image.getHeight());
    }

    public void saveToFile(File file){
        setSavedFile(file);
        if(getFileExt(file).equalsIgnoreCase(getFileExt(openedFile))){
            WritableImage writableImage = snapshotCanvas();
            if(getFileExt(openedFile).equals("png")){
                savePNG(writableImage, file);
            }else {
                saveImageTypes(writableImage, file);
            }
        }else{
            Main.paintController.getWarning().SetWarningAlarm();
        }


    }

    public void savePNG (WritableImage writableImage, File file){
        RenderedImage renderedImage = SwingFXUtils.fromFXImage(writableImage, null);
        try{
            ImageIO.write(renderedImage, "png", file);
        }catch (IOException e){
            System.out.println("File not found");
        }

    }

    public void saveImageTypes(WritableImage writableImage, File file){
        BufferedImage image = SwingFXUtils.fromFXImage(writableImage, null);
        BufferedImage rgbImage = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.OPAQUE);
        Graphics2D graphics2D = rgbImage.createGraphics();
        graphics2D.drawImage(image, 0, 0, null);
        try{
            ImageIO.write(rgbImage, getFileExt(file), file);
        }catch (IOException e){
            System.out.println("File not Found");
        }
        graphics2D.dispose();

    }
    public void autoSaveCanvasToFile(){
        String fullPath = autoSaveLocation + getFileExt(openedFile);
        File autoSavedFile = new File(fullPath);
        WritableImage writableImage = snapshotCanvas();
        if(getFileExt(autoSavedFile).equals("png")){
            savePNG(writableImage, autoSavedFile);
        }
        else{
            saveImageTypes(writableImage, autoSavedFile);
        }

    }
    public boolean getModified(){
        return modified;

    }

    public String getFileExt(File file){
        String FILE = file.getName();
        if(FILE.lastIndexOf(".") != -1 && FILE.lastIndexOf(".") != 0){
            return FILE.substring(FILE.lastIndexOf(".")+1);
        }else{
            return"";
        }

    }

    public File getOpenedFile(){
        return openedFile;

    }

    public void setOpenedFile(File file){
        this.openedFile = file;

    }

    public File getSaveFile(){
        return savedFile;

    }
    public void setSavedFile(File file){
        this.savedFile = file;

    }

    public GraphicsContext getGC(){
        return gc;

    }

    public WritableImage snapshotCanvas(){
        WritableImage writableImage = new WritableImage((int)canvas.getWidth(), (int)canvas.getHeight());
        SnapshotParameters param = new SnapshotParameters();
        param.setFill(Color.TRANSPARENT);
        canvas.snapshot(param, writableImage);
        return writableImage;
    }

    public WritableImage snapshotCanvas(SnapshotParameters param, double width, double height){
        WritableImage writableImage = new WritableImage((int) width, (int) height);
        canvas.snapshot(param, writableImage);
        return writableImage;

    }

    public void setDrawingMode(DrawingMode mode){
        this.drawMode = mode;
    }
    public void setDrawTools(TOOLS type){
        this.drawTools = type;

    }
    public TOOLS getDrawTools(){
        return drawTools;

    }
    public void setStrokeColor(Color color){
        this.strokeColor = color;
        gc.setStroke(color);

    }
    public void setStrokeWidth(Slider slider){
        int width = (int) slider.getValue();
        gc.setLineWidth(width);
    }
    public void setNumSides(int sides){
        Sides = sides;
    }

    public Canvas getCanvas(){
        return canvas;

    }
    public void setRedrawnImage(Image image){
        this.redrawnImage = image;

    }

    public void setCurrentSelection(ImageView image){
        currentSelection = image;

    }
    public Selection getSelection(){
        return selection;

    }
    public void rotate(){
        Rotate rotate = new Rotate(90,canvas.getWidth()/2, canvas.getHeight()/2);
        Main.paintController.getBetterCanvas().getCanvas().getTransforms().add(rotate);

    }
    public void FlipVert(){
        this.canvas.setScaleY(-1);

    }
    public void FlipHori(){
        this.canvas.setScaleX(-1);

    }
    public void canvasClear(){
            javafx.scene.control.Label Question = new javafx.scene.control.Label("Do you want to clear?");
            javafx.scene.control.Button yes = new javafx.scene.control.Button("yes");
            javafx.scene.control.Button no = new Button("no");
            GridPane pane = new GridPane();
            pane.setHgap(10);
            pane.setVgap(10);
            Scene scene = new Scene(pane, 600, 300);
            Stage stage = new Stage();
            stage.setScene(scene);
            stage.show();


            pane.add(Question, 0, 0);
            pane.add(yes, 0, 1);
            pane.add(no, 2, 1);
            pane.setAlignment(Pos.CENTER);
            yes.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    canvas.getGraphicsContext2D().clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
                    stage.close();
                }
            });
            no.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    stage.close();
                }
            });

    }
    public Image getRegion(double x, double y, double x1, double y1){
        SnapshotParameters sp = new SnapshotParameters();
        WritableImage wi = new WritableImage((int)Math.abs(x - x1), (int)Math.abs(y-y1));

        sp.setViewport(new Rectangle2D(
                (x < x1 ? x:x1),(y<y1 ? y : y1), Math.abs(x-x1), Math.abs(y-y1)

        ));
        this.snapshot(sp, wi);
        return wi;
    }
    public void undoLastAction(){
        if(undoHistory.isEmpty()){
            return;
        }
        redoHistory.push(redrawnImage);
        redrawnImage = undoHistory.pop();
        redrawCanvas();

    }
    public void redoLastAction(){
        if(redoHistory.isEmpty()){
            return;
        }
        undoHistory.push(redrawnImage);
        redrawnImage = redoHistory.pop();
        redrawCanvas();
    }

}

package com.example.paint;


import Drawing.DrawingMode;
import Drawing.TOOLS;
import WarningFolder.AboutNoti;
import WarningFolder.HelpNoti;
import WarningFolder.SmartSave;
import WarningFolder.Warning;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.layout.AnchorPane;

public class PaintFXController extends Controller{
    /**
     * sets the Scene of the application*
     */

    @FXML
    private Canvas Canvas;

    @FXML
    private ToolBar CanvasAdjustment;

    @FXML
    private Button CanvasAdjustmentBtn;

    @FXML
    private TextField CanvasHeightTxtBox;

    @FXML
    private ToolBar CanvasResize;

    @FXML
    private Button CanvasSizeBtn;

    @FXML
    private TextField CanvasWidthTxtBox;

    @FXML
    private Button ConfirmCanvasSizeBtn;

    @FXML
    private Button CopySelection;

    @FXML
    private VBox LeftSideToggleVbox;
    @FXML
    private Label ToolLabel;

    @FXML
    private TabPane MainTabPane;
    @FXML
    private Label autoSaveLabel;

    @FXML
    private MenuItem MenuAbout;

    @FXML
    private MenuItem MenuClose;

    @FXML
    private MenuItem MenuHelp;

    @FXML
    private Tab NewTab;

    @FXML
    private Spinner<?> NgonSides;

    @FXML
    private MenuItem OpenMenu;

    @FXML
    private Pane Pane;

    @FXML
    private ToolBar PencilButtonBar;

    @FXML
    private MenuItem SaveAsMenu;
    @FXML
    private Button Undo;

    @FXML
    private Button Redo;

    @FXML
    private MenuItem SaveMenu;

    @FXML
    private ScrollPane ScrollPane;

    @FXML
    private ToolBar ShapesButtonBar;

    @FXML
    private Slider SizeOfTool;

    @FXML
    private ToggleButton ToggleEyedropperBtn;

    @FXML
    private ToggleButton ToggleLineButton;

    @FXML
    private ToggleButton ToggleNgonBtn;

    @FXML
    private ToggleGroup Tool;

    @FXML
    private BorderPane borderPane;

    @FXML
    private ColorPicker colorpicker;

    @FXML
    private Tab initialTab;

    @FXML
    private ToggleButton toggleCircleBtn;

    @FXML
    private ToggleButton toggleEllipseBtn;

    @FXML
    private ToggleButton toggleEraserBtn;

    @FXML
    private ToggleButton togglePencilBtn;

    @FXML
    private ToggleButton toggleRectBtn;

    @FXML
    private ToggleButton toggleSelectorBtn;

    @FXML
    private Button toggleShapesBtn;

    @FXML
    private ToggleButton toggleSquareBtn;

    @FXML
    private ToggleButton toggleTriangleBtn;



    private Warning warning;
    private UpgradedFileChooser saveChooser;
    private UpgradedFileChooser openChooser;
    private PaintCanvas BetterCanvas;
    private HelpNoti helpNoti;
    private AboutNoti aboutNoti;
    private SmartSave smartSave;
    private Boolean visible = true;
    private Threads thread;

    public PaintFXController(){
        Main.paintController = this;

    }


    public PaintCanvas getBetterCanvas(){
        return BetterCanvas;

    }
    public Threads getAutoSaveThread(){
        return thread;

    }


    @FXML
    void Close(ActionEvent event) {
        if(BetterCanvas.getModified()== true){
            smartSave.setSmartSave();
        }else {
            System.exit(0);
        }
    }

    @FXML
    public void Open(ActionEvent event) {
        File openedFile = openChooser.getFileChooser().showOpenDialog(borderPane.getScene().getWindow());
        if(openedFile == null){
            return;
        }
        BetterCanvas.loadImageFromFile(openedFile);
        try{
            thread.logFile(openedFile.getName(), true);
        }catch(IOException ex){
            Logger.getLogger(PaintFXController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    @FXML
    void MenuToggleAbout(ActionEvent event) {
        aboutNoti.createAboutNotify();
    }

    @FXML
    void MenuToggleHelp(ActionEvent event) {
        helpNoti.createHelpNoti();
    }

    @FXML
    void SaveAs(ActionEvent event) {

        File savedFile = saveChooser.getFileChooser().showSaveDialog(borderPane.getScene().getWindow());
        if(savedFile == null){
            return;
        }
        BetterCanvas.saveToFile(savedFile);
        try{
            thread.logFile(savedFile.getName(), true);
        }catch(IOException ex){
            Logger.getLogger(PaintFXController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    public void save(ActionEvent event) {
        if(BetterCanvas.getSaveFile() == null){
            SaveAsMenu.fire();
            return;
        }
        BetterCanvas.saveToFile(BetterCanvas.getSaveFile());
        try{
            thread.logFile(BetterCanvas.getSaveFile().getName(), true);
        }catch(IOException ex){
            Logger.getLogger(PaintFXController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    @FXML
    void toggleCircleAction(ActionEvent event) {
        if(toggleCircleBtn.isSelected()){
            BetterCanvas.setDrawingMode(DrawingMode.DRAW);
            BetterCanvas.setDrawTools(TOOLS.CIRCLE);
        }else{
            BetterCanvas.setDrawTools(TOOLS.NONE);
        }
    }

    @FXML
    void toggleEllipseAction(ActionEvent event) {
        if(toggleEllipseBtn.isSelected()){
            BetterCanvas.setDrawingMode(DrawingMode.DRAW);
            BetterCanvas.setDrawTools(TOOLS.ELLIPSE);
        }else{
            BetterCanvas.setDrawTools(TOOLS.NONE);
        }
    }

    @FXML
    void toggleEraseAction(ActionEvent event) {
        if(toggleEraserBtn.isSelected()){
            BetterCanvas.setDrawingMode(DrawingMode.DRAW);
            BetterCanvas.setDrawTools(TOOLS.ERASER);
        }else{
            BetterCanvas.setDrawTools(TOOLS.NONE);
        }
        PencilButtonBar.toFront();
    }

    @FXML
    void togglePencilAction(ActionEvent event) {
        if(togglePencilBtn.isSelected()){
            BetterCanvas.setDrawingMode(DrawingMode.DRAW);
            BetterCanvas.setDrawTools(TOOLS.PENCIL);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());
        }else{
            BetterCanvas.setDrawTools(TOOLS.NONE);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());

        }
        try{
            thread.logTool(BetterCanvas.getDrawTools().toString());
        }catch (IOException ex){
            Logger.getLogger(PaintFXController.class.getName()).log(Level.SEVERE, null, ex);
        }
        PencilButtonBar.toFront();


    }

    @FXML
    void toggleRectAction(ActionEvent event) {
        if(toggleRectBtn.isSelected()){
            BetterCanvas.setDrawingMode(DrawingMode.DRAW);
            BetterCanvas.setDrawTools(TOOLS.RECTANGLE);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());
        }else{
            BetterCanvas.setDrawTools(TOOLS.NONE);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());

        }
        try{
            thread.logTool(BetterCanvas.getDrawTools().toString());
        }catch (IOException ex){
            Logger.getLogger(PaintFXController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    void toggleSelectorAction(ActionEvent event) {
        if(toggleSelectorBtn.isSelected()){
            BetterCanvas.setDrawingMode(DrawingMode.SELECT);
            BetterCanvas.setDrawTools(TOOLS.SELECT);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());
        }else{
            BetterCanvas.setDrawTools(TOOLS.NONE);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());

        }
        try{
            thread.logTool(BetterCanvas.getDrawTools().toString());
        }catch (IOException ex){
            Logger.getLogger(PaintFXController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void toggleShapesAction(ActionEvent event) {
        ShapesButtonBar.toFront();
    }

    @FXML
    void toggleSquareAction(ActionEvent event) {
        if(toggleSquareBtn.isSelected()){
            BetterCanvas.setDrawingMode(DrawingMode.DRAW);
            BetterCanvas.setDrawTools(TOOLS.SQUARE);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());
        }else{
            BetterCanvas.setDrawTools(TOOLS.NONE);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());

        }
        try{
            thread.logTool(BetterCanvas.getDrawTools().toString());
        }catch (IOException ex){
            Logger.getLogger(PaintFXController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void toggleTriangleAction(ActionEvent event) {
        if(toggleTriangleBtn.isSelected()){
            BetterCanvas.setDrawingMode(DrawingMode.DRAW);
            BetterCanvas.setDrawTools(TOOLS.TRIANGLE);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());
        }else{
            BetterCanvas.setDrawTools(TOOLS.NONE);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());

        }
        try{
            thread.logTool(BetterCanvas.getDrawTools().toString());
        }catch (IOException ex){
            Logger.getLogger(PaintFXController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    @FXML
    void ColorPickerAction(ActionEvent event) {
        BetterCanvas.setStrokeColor(colorpicker.getValue());
    }
    @FXML
    void ToggleNgonAction(ActionEvent event) {
        if(ToggleNgonBtn.isSelected()){
            BetterCanvas.setDrawingMode(DrawingMode.DRAW);
            BetterCanvas.setDrawTools(TOOLS.NGON);
        }else{
            BetterCanvas.setDrawTools(TOOLS.NONE);
        }
    }

    @FXML
    void toggleEyedropperAction(ActionEvent event) {
        if(ToggleEyedropperBtn.isSelected()){
            BetterCanvas.setDrawingMode(DrawingMode.DRAW);
            BetterCanvas.setDrawTools(TOOLS.EYEDROPPER);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());
        }else{
            BetterCanvas.setDrawTools(TOOLS.NONE);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());

        }
        try{
            thread.logTool(BetterCanvas.getDrawTools().toString());
        }catch (IOException ex){
            Logger.getLogger(PaintFXController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    @FXML
    void toggleLineAction(ActionEvent event) {
        if(ToggleLineButton.isSelected()){
            BetterCanvas.setDrawingMode(DrawingMode.DRAW);
            BetterCanvas.setDrawTools(TOOLS.LINE);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());
        }else{
            BetterCanvas.setDrawTools(TOOLS.NONE);
            setToolLabel("Tool Selected: " + BetterCanvas.getDrawTools().toString());

        }
        try{
            thread.logTool(BetterCanvas.getDrawTools().toString());
        }catch (IOException ex){
            Logger.getLogger(PaintFXController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    void CopySelectionAction(ActionEvent event) {
        BetterCanvas.getSelection().setCopy(true);
    }
    public void NgonSpinnerSetUp(Spinner spinner) throws NumberFormatException{
        spinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(5, 99));
        TextFormatter formatter = new TextFormatter(spinner.getValueFactory().getConverter(), spinner.getValueFactory().getValue());
        spinner.getEditor().setTextFormatter(formatter);
        spinner.getValueFactory().valueProperty().bindBidirectional(formatter.valueProperty());
        spinner.valueProperty().addListener((e) -> BetterCanvas.setNumSides((int) spinner.getValue()));

    }
    @FXML
    void ToggleRotate(ActionEvent event) {
        BetterCanvas.rotate();
    }
    @FXML
    void ToggleRotate180(ActionEvent event) {
        BetterCanvas.rotate();
        BetterCanvas.rotate();

    }

    @FXML
    void ToggleRotate270(ActionEvent event) {
        BetterCanvas.rotate();
        BetterCanvas.rotate();
        BetterCanvas.rotate();
    }

    @FXML
    void ToggleSizeConfirm(ActionEvent event) {
        BetterCanvas.getCanvas().setWidth(Integer.parseInt(CanvasWidthTxtBox.getText()));
        BetterCanvas.getCanvas().setHeight(Integer.parseInt(CanvasHeightTxtBox.getText()));

    }
    @FXML
    void ToggleCanvasAdjustmentBar(ActionEvent event) {
        CanvasAdjustment.toFront();
    }

    @FXML
    void ToggleCanvasSizeBar(ActionEvent event) {
        CanvasResize.toFront();
    }

    @FXML
    void ToggleFlipHorizontal(ActionEvent event) {
        BetterCanvas.FlipHori();
    }

    @FXML
    void ToggleFlipVertical(ActionEvent event) {
        BetterCanvas.FlipVert();
    }
    @FXML
    void ToggleClearCanvas(ActionEvent event) {
        BetterCanvas.canvasClear();
    }
    @FXML
    void ToggleUndo(ActionEvent event) {
        BetterCanvas.undoLastAction();
    }
    @FXML
    void ToggleRedo(ActionEvent event) {
        BetterCanvas.redoLastAction();
    }

    @FXML
    void handleAutoSaveVisibility(ActionEvent event) {
        if(visible == true){
            autoSaveLabel.setVisible(false);
            visible = false;
        }else{
            autoSaveLabel.setVisible(true);
            visible = true;
        }
    }
    public void setToolLabel(String string){
        ToolLabel.setText(string);

    }


    /**
     * initializes the various tools in the program*
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        super.initialize(url, resourceBundle);
        NgonSpinnerSetUp(NgonSides);
        BetterCanvas = new PaintCanvas(Canvas);
        ScrollPane = new ScrollPane(Canvas);
        initialTab.setContent(ScrollPane);
        saveChooser = new UpgradedFileChooser("Save Canvas:");
        openChooser = new UpgradedFileChooser("Open Image:");
        warning = new Warning(BetterCanvas);
        helpNoti = new HelpNoti();
        aboutNoti = new AboutNoti();
        smartSave = new SmartSave(BetterCanvas, saveChooser);

        thread = new Threads(60);
        thread.startAutoSave();



        SizeOfTool.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                BetterCanvas.setStrokeWidth(SizeOfTool);
            }

        });
        NewTab.setOnSelectionChanged(e->{
            Tab tab = new Tab("Tab ");
            Canvas canvas = new Canvas();
            this.BetterCanvas = new PaintCanvas(canvas);
            ScrollPane scrollpane = new ScrollPane(canvas);
            tab.isClosable();
            tab.setContent(scrollpane);
            colorpicker.setValue(Color.BLACK);
            SizeOfTool.setValue(10);
            MainTabPane.getTabs().add(MainTabPane.getTabs().size()-1, tab);
            MainTabPane.getSelectionModel().select(MainTabPane.getTabs().size()-2);
        });

    }
    public ColorPicker getColorPicker(){
        return colorpicker;
    }
    @FXML
    void newTabAction(ActionEvent event) {

    }

    public Warning getWarning() {
        return warning;

    }
    public Pane getPane(){
        return Pane;

    }
    public void setAutoSaveLabel(String string){
        autoSaveLabel.setText(string);

    }

}

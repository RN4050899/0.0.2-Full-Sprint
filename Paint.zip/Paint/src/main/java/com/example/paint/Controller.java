package com.example.paint;

import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    protected PaintCanvas BetterCanvas;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        BetterCanvas = Main.paintController.getBetterCanvas();

    }
}

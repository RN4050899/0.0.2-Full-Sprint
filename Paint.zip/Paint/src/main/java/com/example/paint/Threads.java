package com.example.paint;

import java.io.File;

import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javafx.application.Platform;

public class Threads {
    private final Thread thread;
    int time= 0;
    int saveInterval;
    private final File logFile;
    private final String logs = "com/example/paint/logs/txt";
    String currentTool = "NONE";

    /**
     * creates the thread timer and trigger autosave*
     * @param saveInterval
     */
    public Threads(int saveInterval){
        logFile = new File(logs);
        checkLogDelete();
        this.saveInterval = saveInterval;
        thread = new Thread(()->{
            while (true){
                handleAutoSave();
            }
        });
        thread.setDaemon(true);
    }
    public void startAutoSave(){
        thread.start();

    }
    private void handleAutoSave(){
        try{
            for(int i = saveInterval; i>0; i--){
                int count = i;
                time++;
                Platform.runLater(()->{
                    Main.paintController.setAutoSaveLabel("Saving CountDown: " + count);

                });
                Thread.sleep(1000);
            }
        }catch (Exception e){
        }
        try{
            Platform.runLater(()->{
                try{
                    Main.paintController.getBetterCanvas().autoSaveCanvasToFile();
                }catch(Exception e){
                    System.out.println("error");
                }

            });
        }catch(IllegalArgumentException e){
            System.out.println("error");
        }

    }
    public File getLogFile(){
        return logFile;

    }
    public int getTime(){
        return time;

    }
    public void logTool(String tool) throws IOException{
        FileWriter fwriter;
        fwriter = new FileWriter(logFile, true);
        fwriter.append(currentTool + ":" + time + " seconds" + System.getProperty("line.separator"));
        fwriter.close();
        currentTool = tool;
        time = 0;
    }
    public void logFile(String fileName, boolean bool) throws IOException{
        FileWriter fwriter;
        DateFormat dateFormat = new SimpleDateFormat("HH:MM:SS");
        Date date = new Date();

        fwriter = new FileWriter(logFile, true);
        if(bool){
            fwriter.append(fileName + " Opened at:" + dateFormat.format(date) + System.getProperty("line.separator"));
            time = 0;
        }else{
            fwriter.append(fileName + " Saved at:" + dateFormat.format(date) + System.getProperty("line.separator"));
        }
        fwriter.close();

    }
    private void checkLogDelete(){
        long lastLogFile = new Date().getTime() - logFile.lastModified();
        int day = 3*24*60*60*1000;

        if(lastLogFile > day){
            logFile.delete();
        }

    }
}

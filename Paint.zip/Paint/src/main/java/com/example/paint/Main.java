package com.example.paint;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class  Main extends Application {

    public static final double WIDTH = 400;
    public static final double HEIGHT = 150;
    public static final double Default_WIDTH = 1024;
    public static final double Default_HEIGHT = 760;

    public static PaintFXController paintController;
    public PaintCanvas BetterCanvas;

    @Override
    public void start(Stage stage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("MainCanvas.fxml"));
        Scene scene = new Scene(root, Default_WIDTH, Default_HEIGHT);

        stage.setScene(scene);
        stage.setMinWidth(WIDTH);
        stage.setMinHeight(HEIGHT);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }


}
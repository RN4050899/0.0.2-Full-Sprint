package com.example.paint;

import javafx.stage.FileChooser;

public class UpgradedFileChooser {
    /**
     * basically filters the file*
     */
    FileChooser fileChooser = new FileChooser();
    String ufctitle;


    public UpgradedFileChooser(String title){
        this.ufctitle = title;
        configFileChooser(fileChooser, ufctitle);
    }

    private void configFileChooser(FileChooser fileChooser, String title) {
        fileChooser.setTitle(title);
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Files", "*.jpeg", "*.jpg",
                        "*.png", "*.JPEG", "*.JPG", "*.PNG", ".Bitmap", "*.bmp"),
                new FileChooser.ExtensionFilter("JPEG", "*.jpeg", "*.jpg",
                        "*.JPEG", "*.JPG"),
                new FileChooser.ExtensionFilter("PNG", "*.png", "*.PNG")
        );
    }

        public FileChooser getFileChooser(){
            return fileChooser;
        }

}

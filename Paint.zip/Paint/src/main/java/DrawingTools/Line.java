package DrawingTools;

import javafx.scene.canvas.GraphicsContext;

public class Line extends BaseShape{
    public Line(double ix, double iy, double fx, double fy) {
        super(ix, iy, fx, fy);
    }
    public Line(double x, double y){
        super(x, y, x, y);

    }

    @Override
    public void draw(GraphicsContext gc) {
        gc.strokeLine(ix, iy, fx, fy);
    }

    @Override
    public void draw(GraphicsContext gc, int sides) {

    }
}

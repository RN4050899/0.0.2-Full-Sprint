package DrawingTools;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Paint;

public class Triangle extends BaseShape {
    public Triangle(double ix, double iy, double fx, double fy) {
        super(ix, iy, fx, fy);
    }
    public Triangle(double x, double y) {
        super(x,y,x,y);
    }

    @Override
    public void draw(GraphicsContext gc) {
        double x2 = ((fx+ix + Math.sqrt(3)*(iy-fy))/2);
        double y2 = ((fy+iy + Math.sqrt(3)*(ix-fx))/2);

        gc.fillPolygon(new double[]{ix, fx, x2}, new double []{iy, fy, y2}, 3);
        gc.strokePolygon(new double[]{ix, fx, x2}, new double []{iy, fy, y2}, 3);

    }

    @Override
    public void draw(GraphicsContext gc, int sides) {
    }
}

package DrawingTools;

import javafx.scene.canvas.GraphicsContext;

public class Circle extends Ellipse{

    public Circle(double startx, double starty, double endx, double endy) {
        super(startx, starty, endx, endy);
    }
    public Circle(double x, double y){
        super(x,y,x,y);

    }

    /**
     * * The math that calculates how the circle is drawn based on Mouse position
     * @param gc
     */
    @Override
    public void draw(GraphicsContext gc){
        double mRadius = Math.min(Math.abs(fx-ix), Math.abs(fy-iy));
        if (Math.abs(fy - iy)>mRadius) {
            if (fy < iy) {
                fy = iy - mRadius;
            } else {
                fy = iy + mRadius;
            }
        }
        if(Math.abs(fx - ix)>mRadius){
            if(fx < ix){
                fx = ix - mRadius;
            }else{
                fx = ix + mRadius;
            }
        }
        super.draw(gc);

    }
}

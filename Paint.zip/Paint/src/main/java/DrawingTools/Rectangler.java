package DrawingTools;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;

public class Rectangler extends BaseShape{
    Rectangle rect;
    public Rectangler(double ix, double iy, double fx, double fy) {
        super(ix, iy, fx, fy);
    }
    public Rectangler(double x, double y){
        super(x,y,x,y);

    }

    @Override
    public void draw(GraphicsContext gc) {
        boolean xPos = fx - ix >= 0;
        boolean yPos = fy - iy >= 0;
        gc.fillRect(xPos ? ix:fx, yPos ? iy : fy, xPos ? fx - ix : ix - fx, yPos ? fy - iy : iy - fy);
        gc.strokeRect(xPos ? ix:fx, yPos ? iy : fy, xPos ? fx - ix : ix - fx, yPos ? fy - iy : iy - fy);
    }

    @Override
    public void draw(GraphicsContext gc, int sides) {
    }

    public void drawSelection(GraphicsContext gc){
        boolean xPos = fx - ix >= 0;
        boolean yPos = fy - iy >= 0;
        Paint beforeStrokeColor = gc.getStroke();
        Paint beforeFillColor = gc.getFill();
        double beforeLineWidth = gc.getLineWidth();

        gc.setFill(Color.TRANSPARENT);
        gc.setStroke(Color.BLACK);
        gc.setLineDashes(4);
        gc.setLineWidth(1);
        gc.fillRect(xPos ? ix:fx, yPos ? iy : fy, xPos ? fx - ix : ix - fx, yPos ? fy - iy : iy - fy);
        gc.strokeRect(xPos ? ix:fx, yPos ? iy : fy, xPos ? fx - ix : ix - fx, yPos ? fy - iy : iy - fy);
        gc.setStroke(beforeStrokeColor);
        gc.setFill(beforeFillColor);
        gc.setLineDashes(0);
        gc.setLineWidth(beforeLineWidth);
    }
}

package DrawingTools;

import javafx.scene.canvas.GraphicsContext;

public class Ngon extends BaseShape{
    private double rotation;


    public Ngon(double x, double y){
        super(x,y,x,y);
        setIsPolygon();
        setRotation(Math.PI);

    }
    @Override
    public void setEnd(double fx, double fy){
        super.setEnd(fx, fy);
    }

    @Override
    public void draw(GraphicsContext gc) {
    }

    @Override
    public void draw(GraphicsContext gc, int sides) {
        boolean xPos = fx - ix >= 0;
        boolean yPos = fy - iy >= 0;
        final double angleMath = Math.PI * 2 / sides;
        double angle = 0;
        double radiusMath = Math.sqrt(Math.pow((fx - ix), 2) + Math.pow((fy - iy), 2));
        double[] xPoint = new double[sides];
        double[] yPoint = new double[sides];
        for(int i = 0; i < sides; i++, angle+=angleMath){
            xPoint[i] = Math.sin(angle+rotation)*radiusMath+ix;
            yPoint[i] = Math.cos(angle+rotation)*radiusMath+iy;
        }
        gc.fillPolygon(xPoint, yPoint, sides);
        gc.strokePolygon(xPoint,yPoint,sides);
    }
    @Override
    public final void setIsPolygon(){
        isPolygon = true;
    }

    public final void setRotation(double number){
        rotation = number;
    }
}

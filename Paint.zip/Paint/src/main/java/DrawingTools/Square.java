package DrawingTools;

import javafx.scene.canvas.GraphicsContext;

public class Square extends Rectangler{
    public Square(double ix, double iy, double fx, double fy) {
        super(ix, iy, fx, fy);
    }
    public Square(double x, double y) {
        this(x, y, x, y);
    }
    @Override
    public void draw(GraphicsContext gc){
        double mWidth = Math.min(Math.abs(fx-ix), Math.abs(fy-iy));
        if (Math.abs(fy - iy)>mWidth) {
            if (fy < iy) {
                fy = iy - mWidth;
            } else {
                fy = iy + mWidth;
            }
        }
        if(Math.abs(fx - ix)>mWidth){
            if(fx < ix){
                fx = ix - mWidth;
            }else{
                fx = ix + mWidth;
            }
        }
        super.draw(gc);

    }
}

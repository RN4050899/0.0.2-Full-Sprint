package DrawingTools;

import javafx.scene.canvas.GraphicsContext;

public class Ellipse extends BaseShape{
    public Ellipse(double startx, double starty, double endx, double endy){
        super(startx, starty, endx, endy);
    }

    public Ellipse(double x, double y){
        super(x,y,x,y);
    }

    /**
     * * Tool that draws ellipse based on mouse position
     * @param gc
     */
    @Override
    public void draw(GraphicsContext gc){
        boolean xPos = fx - ix >= 0;
        boolean yPos = fy - iy >= 0;
        gc.fillOval(xPos ? ix:fx, yPos ? iy : fy, xPos ? fx - ix : ix - fx, yPos ? fy - iy : iy - fy);
        gc.strokeOval(xPos ? ix:fx, yPos ? iy : fy, xPos ? fx - ix : ix - fx, yPos ? fy - iy : iy - fy);

    }

    @Override
    public void draw(GraphicsContext gc, int sides) {
    }
}

package DrawingTools;

import com.example.paint.Main;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;

public class Selection {
    private WritableImage image;
    double startX, startY;
    double endx, endy;
    boolean copy = false;
    boolean paste = false;
    private ImageView currentSelection;


    public Selection(double startx, double starty, double endX, double endY){
        startX = startx;
        startY = starty;
        endx = endX;
        endy = endY;
    }
    public Selection(double x, double y){
        startX = x;
        startY = y;
        endy = y;
        endx = x;

    }

    public void setEnd(double x, double y){
        endx = x;
        endy = y;

    }
    private void selectionSetUp(GraphicsContext gc){
        WritableImage previousImage = new WritableImage(
                (int) Main.paintController.getBetterCanvas().getCanvas().getWidth(),
                (int) Main.paintController.getBetterCanvas().getCanvas().getHeight()
        );

        Main.paintController.getBetterCanvas().getCanvas().snapshot(null, previousImage);
        if(startX>endx){
            double temp = endx;
            endx = startX;
            startX = temp;
        }
        if(startY > endy){
            double temp = endy;
            endy = startY;
            startY = temp;
        }
        WritableImage newImage = new WritableImage(previousImage.getPixelReader(),
                (int)startX, (int)startY, (int)Math.abs(startX-endx),
                (int)Math.abs(startY-endy));

        currentSelection = new ImageView(newImage);
    }



    public void setImage(GraphicsContext gc){

        selectionSetUp(gc);
        Paint colorBefore = gc.getFill();
        currentSelection.setX(startX);
        currentSelection.setY(startY);
        currentSelection.setOnMousePressed(event -> {
            if(!copy){
                gc.setFill(Color.WHITE);
                gc.fillRect(startX, startY, Math.abs(endx - startX), Math.abs(endy - startY));
                Main.paintController.getBetterCanvas().setRedrawnImage(Main.paintController.getBetterCanvas().getCanvas().snapshot(null, null));
            }

            startX = (event.getX()- currentSelection.getX());
            startY = (event.getY()- currentSelection.getY());
        });
        currentSelection.setOnMouseDragged(event -> {
            currentSelection.setX(event.getX()- startX);
            currentSelection.setY(event.getY()- startY);
            event.consume();
        });
        currentSelection.setOnMouseReleased(event -> {
            Main.paintController.getPane().getChildren().remove(currentSelection);
            gc.drawImage(currentSelection.getImage(),currentSelection.getX(),currentSelection.getY());
            currentSelection = null;
            Main.paintController.getBetterCanvas().setCurrentSelection(null);
            setCopy(false);
            gc.setFill(colorBefore);

        });
        Main.paintController.getPane().getChildren().add(currentSelection);
        gc.setFill(colorBefore);
    }

    public void setCopy(boolean boo){
        this.copy = boo;

    }

    public void setEndy(double endy){
        this.endy = endy;

    }
    public void setEndx(double endx){
        this.endx = endx;

    }
    public void setStartX(double startX){
        this.startX = startX;

    }
    public void setStartY(double startY){
        this.startY = startY;

    }
    public double getStartX(){
        return startX;
    }

    public double getEndx(){
        return endx;
    }

    public double getStartY(){
        return startY;
    }

    public double getEndy(){
        return endy;
    }

    public ImageView getCurrentSelection(){
        return currentSelection;

    }
}


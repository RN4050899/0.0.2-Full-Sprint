package DrawingTools;

import javafx.scene.canvas.GraphicsContext;

public abstract class BaseShape {
    /**
     * the class that all other shape class must follow, the base shape*
     */
    protected double ix, fx;
    protected double iy, fy;

    protected boolean isPolygon;


    public BaseShape(double ix, double iy, double fx, double  fy){
        this.ix = ix;
        this.iy = iy;
        this.fx = fx;
        this.fy = fy;

    }

    public abstract void draw(GraphicsContext gc);
    public abstract void draw(GraphicsContext gc, int sides);


    public void setEnd(double x, double y){
        this.fx = x;
        this.fy = y;
    }

    public boolean getIsPolygon(){
        return isPolygon;

    }
    public void setIsPolygon(){
        isPolygon = false;

    }
}

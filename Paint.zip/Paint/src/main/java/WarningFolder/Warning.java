package WarningFolder;

import com.example.paint.PaintCanvas;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.WritableImage;
import java.util.Optional;

public class Warning {
    private final PaintCanvas BetterCanvas;

    /**
     * creates a warning if someone using the application tries to leave before saving.*
     * @param BetterCanvas
     */

    public Warning(PaintCanvas BetterCanvas){
        this.BetterCanvas = BetterCanvas;

    }

    public void SetWarningAlarm(){
        Alert alert = createWarningAlert();
        ButtonType yes = new ButtonType("Yes");
        ButtonType cancel = new ButtonType("Cancel");

        alert.getButtonTypes().setAll(yes, cancel);

        Optional<ButtonType> answer = alert.showAndWait();
        handleButton(answer, yes, cancel);

    }

    private Alert createWarningAlert(){
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText(("You have changed file. The file may be unsuable or lost"));
        alert.setContentText("Continue file " + BetterCanvas.getFileExt(BetterCanvas.getSaveFile()).toUpperCase()+"?");
        return alert;
    }

    private void handleButton(Optional<ButtonType> answer, ButtonType yes, ButtonType cancel){
        if(answer.get() == yes){
            WritableImage writableImage = BetterCanvas.snapshotCanvas();
            if(BetterCanvas.getFileExt(BetterCanvas.getOpenedFile()).equals("png")){
                BetterCanvas.savePNG(writableImage, BetterCanvas.getSaveFile());
            }else{
                BetterCanvas.saveImageTypes(writableImage, BetterCanvas.getSaveFile());
            }
        }else if(answer.get() == cancel){
            BetterCanvas.getSaveFile().delete();
        }

    }
}

package WarningFolder;

import com.example.paint.Main;
import com.example.paint.PaintCanvas;
import com.example.paint.UpgradedFileChooser;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;

import java.beans.beancontext.BeanContext;
import java.io.File;
import java.util.Optional;

public class SmartSave {
    private PaintCanvas paintCanvas;
    private UpgradedFileChooser ufc;
    File file;

    /**
     * creates the save that triggers when it detects changes to the canvas*
     * @param paintCanvas
     * @param ufc
     */
    public SmartSave(PaintCanvas paintCanvas, UpgradedFileChooser ufc){
        this.paintCanvas = paintCanvas;
        this.ufc = ufc;

    }

    public void setSmartSave(){
        Alert alert = createCloseDialog();

        ButtonType yes = new ButtonType("Yes");
        ButtonType no = new ButtonType("no");

        alert.getButtonTypes().setAll(yes, no);
        Optional<ButtonType> end = alert.showAndWait();
        handleButtonType(end, yes, no);

    }

    private Alert createCloseDialog(){
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("CAREFUL!");
        alert.setHeaderText("The file is not saved. Would you like to save?");
        return alert;

    }
    private void handleButtonType(Optional<ButtonType> end, ButtonType yes, ButtonType no){
        if(end.get()==yes){
            if(paintCanvas.getSaveFile()==null){
                paintCanvas.setSavedFile(ufc.getFileChooser().showSaveDialog(Main.paintController.getPane().getScene().getWindow()));
            }
            paintCanvas.saveToFile(paintCanvas.getSaveFile());
            Platform.exit();
        }else if(end.get()==no){
            Platform.exit();
        }

    }
}

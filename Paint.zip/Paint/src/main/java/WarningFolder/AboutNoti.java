package WarningFolder;

import javafx.scene.control.Alert;

public class AboutNoti {
    /**
     * creates a dialog that pops up when you go to the about section*
     */
    public void createAboutNotify(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About");
        alert.setHeaderText("Pain(t) Ryan Nguyen");
        alert.showAndWait();
    }
}

package WarningFolder;

import javafx.scene.control.Alert;

public class HelpNoti {
    /**
     *  creates a dialog that pops up when you go to the Help section*
     */
    public void createHelpNoti(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Help");
        alert.setHeaderText("There is no help, there is no salvation");
        alert.showAndWait();
    }
}

package DrawingTools;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LineTest {
    @Test
    public void Line(){
        var Line = new Line(10, 20, 30, 30);
        assertEquals(Line, Line);

    }

}
package DrawingTools;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CircleTest {
    @Test
    public void CircleTest(){
        var Circle = new Circle(10, 10, 30, 30);
        assertEquals(Circle, Circle);
    }
}
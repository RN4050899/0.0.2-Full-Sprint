package com.example.paint;

import Drawing.TOOLS;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ThreadsTest {
    @Test
    public void TestTOOLS(){
        String instance = "PENCIL";
        assertEquals(instance, TOOLS.PENCIL.toString());

    }



}